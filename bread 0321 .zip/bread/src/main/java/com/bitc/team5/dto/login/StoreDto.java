package com.bitc.team5.dto.login;

import lombok.Data;

@Data
public class StoreDto {
	private String storeId;
	private String storeName;
	private String storeDesc;
	private String storeAddr;
}
