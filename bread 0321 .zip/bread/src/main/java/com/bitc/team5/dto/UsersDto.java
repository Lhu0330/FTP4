package com.bitc.team5.dto;

import lombok.Data;

@Data
public class UsersDto {
	
	
//	private int idx;
//	private String userId;
//	private String userPw;
////	private String userName;
//	private String userAddr;
//	private String userPhone;
	//private String userAddrDetail;
	//private String userStore;
	
	
	private int idx;
	private String userId;
	private String userPw;	
	private String userEmail;	
	private String userPhone;	
	private String userAddr;
	private String userAuth;
	private String storeName;
	private String storeDesc;
	private String storeAddr;


}
