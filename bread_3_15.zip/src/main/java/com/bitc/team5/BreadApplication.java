package com.bitc.team5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BreadApplication {

	public static void main(String[] args) {
		SpringApplication.run(BreadApplication.class, args);
	}

}
