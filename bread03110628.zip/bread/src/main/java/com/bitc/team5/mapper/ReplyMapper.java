package com.bitc.team5.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ReplyMapper {

//	void create(reviewDto review);


	

}
