package com.bitc.team5.service;

public interface ReplyService {

//	void create(reviewDto review);
//
//}
}