package com.bitc.team5.dto;

import lombok.Data;

@Data
public class UsersDto {
	
	private int seq;
	private String userId;
	private String userPw;
	private String userName;
	private String userAddr;
	private String userPhone;
	private String userAddrDetail;
	private String userStore;


}
